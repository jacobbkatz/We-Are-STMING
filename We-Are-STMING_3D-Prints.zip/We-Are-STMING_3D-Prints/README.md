# We Are STMing — 3D Printed Parts

Every printable part for the microscope, in four groups.

Parts under `scan-head/` and `isolation/` originate from **Mech Panda's
[red-panda-stm](https://github.com/MechRedPanda/red-panda-stm)** design. Parts under `enclosures/`
are original to this project.

---

## `scan-head/`

The microscope head itself.

| File | Size (mm) | Notes |
|---|---|---|
| `BasePlate.stl` | 100 × 70 × 10 | Nine M3 holes, 3×3 grid. **The grid is offset 7.5 mm from the part centre in X** — offsets are X −37.5 / −7.5 / +22.5, Y −27 / 0 / +27 |
| `PiezoPlate.stl` | 55 × 70 × 15 | Carries the piezo disc and the three fine-adjust screws |
| `SamplePlate.stl` | 12 × 70 × 49 | The movable plate; sample pocket with magnets |
| `MotorSupport.stl` | 10 × 52.3 × 30 | Stepper motor clamp |
| `ThreadAdaptor.stl` | 21.9 × 22 × 17 | Couples the motor shaft to the approach screw |
| `box_mount.stl` | 142 × 128 × 5 | Frame the head sits in. **Opening 131.00 × 101.00**, two M3 holes at (0, ±60) from the opening centre |

## `isolation/`

Vibration isolation stage.

| File | Size (mm) | Notes |
|---|---|---|
| `Platform.stl` | Ø200 × 6 | **Circular disc**, not square — 24 × Ø4.3 mm holes |
| `new_body.stl` / `new_topframe.stl` | — | Bottom and top of the isolation tower, joined by three M8 rods |
| `magnet_mount.stl` | 140 × 158.5 × 5 | Holds the 18 damping magnets |
| `coin_weights.stl` | — | Mass elements |
| `Spring_hangers_and_extentions.stl` | — | Spring anchors |

## `enclosures/`

Original to this project. Every dimension derived from measured Gerber and STL data — not
estimated. All meshes verified watertight and manifold.

| File | Outer (mm) | Purpose |
|---|---|---|
| `1_preamp_box_base/_lid` | 34.8 × 29.4 × 20.8 | Preamplifier shield can. **M2 hardware** |
| `2_controller_box_base/_lid` | 129.2 × 113.9 × 39.8 | Controller PCB, with both DB9 apertures |
| `3_teensy_protoboard_box_base/_lid` | 89.8 × 109.8 × 41.8 | Teensy protoboard (70 × 90 mm) |
| `4_scanhead_box_base/_lid` | 130 × 134 × 88.2 | Alternative scan-head enclosure |
| `5_intermediate_baseplate` | 130 × 100 × 5 | Sits flush in the frame opening; scan module bolts to it |
| `6_shield_cover` | 142 × 128 × 112.4 | Outer shield, drops over the whole scan module |

**Note:** `4_scanhead_box` and `6_shield_cover` are alternatives, not complements. The shield
cover matches Mech Panda's approach (head open on its baseplate, shield lowered over it).

## `print-plates/`

Bambu Studio `.3mf` project files with parts pre-arranged on build plates.

---

## Print settings

| | |
|---|---|
| Material | PETG-CF (Mech Panda used PA-CF; it prints far less reliably at these tolerances) |
| Layer height | 0.2 mm |
| Perimeters | 3+, or 4+ for the intermediate baseplate |
| Infill | 25–30%, or 40%+ for the intermediate baseplate |
| Supports | Not needed — all openings are vertical |

**Orientation:** print boxes open-face-up, lids flat, the baseplate flat, the shield cover
open-face-down.

## Fasteners

| Part | Board screws | Lid screws |
|---|---|---|
| Preamp box | **M2** self-tapping | M2 |
| Controller box | none — support pads + lid pressure | M3 |
| Protoboard box | M3 self-tapping | M3 |
| Intermediate baseplate | M3 × 16 into the scan module | M3 button-head + nut to the platform |

The preamp box is the only part using M2.

**Confirmed purchased hardware** (recovered from the CAD archive metadata):

- **McMaster 97424A590** — ultra-fine-thread thumb screw, **1/4"-80, 1" long**. The three
  fine-adjust screws of the kinematic mount. 80 TPI means one turn moves 0.0125".
- **McMaster 98625A960** — brass insert, 0.438" long, matched to 1/4"-80 ball-point set screws.
  Heat-set into the printed plate.

## Still unconfirmed

Plate-to-plate and motor-mount screw sizes are not stated in any published source and are not
readable from the build video. They are deliberately left unspecified rather than guessed.
