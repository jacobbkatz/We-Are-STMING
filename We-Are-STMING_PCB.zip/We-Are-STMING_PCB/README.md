# We Are STMing — PCB Design Files

Two boards: the **controller** (Mech Panda's design) and the **preamplifier** (Dan Berard's
design). Both are provided as fab-ready Gerbers plus editable source.

---

## `controller/`

The main controller board — four DACs, one ADC, ±15 V regulation, and the ribbon interface to the
Teensy. **103.38 × 88.08 mm, 2-layer.**

| Folder | Contents |
|---|---|
| `gerbers/` | Fab-ready Gerbers + drill files. Verified complete: top/bottom copper, both solder masks, both silkscreens, board outline, three drill files |
| `altium/` | Altium source — `1_ADC`, `2_Connectors`, `3_DAC` schematics and `PCB1.pcbdoc` |
| `altium-analog-project/` | Fuller Altium project including the piezo driver sheet |
| `easyeda_project.zip` | EasyEDA backup — import as a whole, don't unpack |
| `schematic-pdf/` | `SCH_Controller_2023-11-04.pdf` — readable without any EDA tool |
| `bom/` | JLCPCB assembly BOM and component placement file |

`gerbers/FlyingProbeTesting.json` is the manufacturing netlist — every pad with its net name. It
is the authoritative source for what connects to what, and every pinout below was traced from it.

### Ordering notes

The BOM in `bom/` is set up for JLCPCB assembly. Several parts are **not** placed by the assembler
and must be hand-soldered: the **U21 op-amp**, **both DB9 connectors**, and the **U19 power
connector**.

### Verified pinouts

**Ribbon header H1 (2×13, 26-pin)** — all 13 odd pins are AGND:

| Ribbon | Signal | Teensy |
|---|---|---|
| 2 | ADC_CNV | 19 |
| 4 | ADC_BUSY | 18 |
| 6 | ADC_SDI (read-enable / RDL) | 38 |
| 8 | ADC_SCK | 27 |
| 10 | ADC_SDO | 39 |
| 12 | SCLK — shared DAC clock | 13 |
| 14 | SDI — shared DAC data | 11 |
| 16 | SYNC4 — bias DAC | 10 |
| 18 | SYNC2 — Y DAC | 9 |
| 20 | SYNC3 — Z DAC | 8 |
| 22 | SYNC1 — X DAC | 7 |
| 24, 26 | not connected | — |

**J1 / DSUB1 — scanner output:** pin 9 = Z+X · pin 8 = Z−X · pin 7 = Z+Y · pin 6 = Z−Y ·
pins 1–5 = AGND

**J2 / DSUB2 — preamp and power:** pin 1 = BIAS · pin 2 = PREAMP− · pin 3 = PREAMP+ ·
pin 4 = −15 V **out** · pin 5 = +15 V **out** · pins 6–9 = AGND

**Power input is U19**, a 3-pin through-hole connector (2.5 mm pitch): pin 1 = V−−, pin 2 = AGND,
pin 3 = V++. On-board regulators produce ±15 V (U17/U18), 3.3 V (U16) and 5 V (U22), so V++/V−−
must exceed ±15 V. **The ±15 V on J2 is an output feeding the preamplifier — do not connect a
supply there.**

**The stepper motor is not on this board.** There is no motor circuitry anywhere in the design;
the ULN2003 driver wires directly to the Teensy.

---

## `preamplifier/`

Transimpedance amplifier that converts the picoamp tunneling current into a measurable voltage.
**20.625 × 15.23 mm.** Dan Berard's design — the Eagle source carries his MIT license.

| Folder | Contents |
|---|---|
| `gerbers/` | Fab-ready Gerbers + drill. Complete: both copper layers, masks, silkscreen, edge cuts |
| `eagle/` | `tunnelAmp.brd` / `tunnelAmp.sch` — editable Eagle source, plus the original licence |

### The critical detail: the input node is air-wired

The op-amp's inverting input (IC1 pin 2) has **zero copper connected to it on either layer.** This
is deliberate — at picoamp currents, leakage across the PCB surface would swamp the signal.

The input junction is built **in the air** on an insulated (PTFE) standoff pressed into a bare,
unplated hole. The 100 MΩ feedback resistor, the tip wire, and a link to IC1 pin 2 all meet there.

**`PAD1` is the amplifier OUTPUT** (traced to IC1 pin 6), not the tip input. Wiring the tip to
PAD1 would connect it to the output and measure nothing.

Three holes on the left of the board have soldermask openings but **no copper** — they are bare
mechanical holes, not pads: Ø2.108 mm at (2.540, 7.620) and Ø2.261 mm at (4.127, 13.335) and
(4.127, 1.905).

**JP1** is the 5-pin power/output header at x = 18.732 mm.

---

## Credits

- **Controller** — Mech Panda, [red-panda-stm](https://github.com/MechRedPanda/red-panda-stm)
- **Preamplifier** — Dan Berard, [dberard.com/home-built-stm](https://dberard.com/home-built-stm/)
  (MIT licensed; original licence retained in `preamplifier/eagle/`)

All pinouts above were traced from the boards' own manufacturing data and cross-checked against
the firmware source. Where the two disagreed, the discrepancy was resolved before publishing.
